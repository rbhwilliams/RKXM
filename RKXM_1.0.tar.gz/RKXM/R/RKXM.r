process.spades.contigs<-function(contigs)
{
 #--function to extract relevant information from a SPAdes assembly ('contigs')
 #--returns a length, (k-mer) coverage, GC table
 contigsNamesSplitList<-strsplit(names(contigs),"_") 
 cov<-as.numeric(sapply(contigsNamesSplitList,FUN=function(x){x[6]}))
 len<-width(contigs)
 contigs.1merMat<-Biostrings::oligonucleotideFrequency(contigs,1)
 gc<-rowSums(contigs.1merMat[,c("G","C")])/rowSums(contigs.1merMat)
 cnames<-sapply(contigsNamesSplitList,FUN=function(x){paste(x[1],x[2],sep="_")})
 res<-data.frame(len=len,cov=cov,gc=gc,row.names=cnames,stringsAsFactors=F)
 res
}

simplify.contig.data<-function(contigData,minlen=1500)
{
 #--'contigData' is an output from 'process.spades.contigs'
 contigDataCut<-subset(contigData,len>=minlen)
 res<-cbind(lgcov=log10(contigDataCut$cov),gc=contigDataCut$gc,len=contigDataCut$len)
 rownames(res)<-rownames(contigDataCut)
 res
}

extract.contig2orf.summary.table<-function(orfFASTAFilePath,contigSummData)
{
 #--'orfFASTAFilePath' is a path to an output from Prodigal (from a SPADes asembled contig set)
 #--'contigSummData' is an output from 'process.spades.contigs' (not 'simplify.contig.data' as we are capturing all contigs)
 orfFASTA<-readDNAStringSet(filepath=orfFASTAFilePath)
 orfFASTA.simpleNames<-sapply(strsplit(sapply(strsplit(names(orfFASTA)," #"),FUN=function(x){x[1]}),"_"),FUN=function(x){paste(x[1],x[2],x[7],sep="_")})
 names(orfFASTA)<-orfFASTA.simpleNames
 orfFASTA.contigs<-sapply(strsplit(names(orfFASTA),"_"),FUN=function(x){paste(x[1],x[2],sep="_")})
 orfData<-data.frame(contigs=orfFASTA.contigs,
                             len=contigSummData[orfFASTA.contigs,"len"],
                             orf=names(orfFASTA),stringsAsFactors=F)
 return(orfData)
}

simplify.orf.names<-function(taxScan)
{
 res=NULL
 curs<-strsplit(taxScan,"; ;",fixed=T)
 r1<-sapply(curs,FUN=function(x){strsplit(x[1],"_")})
 n1<-sapply(r1,FUN=function(x){paste(x[1],x[2],x[7],sep="_")})
 r2<-sapply(curs,FUN=function(x){x[2]})
 r2[is.na(r2)]<-""
 res<-apply(data.frame(n1,r2,stringsAsFactors=F),1,FUN=paste,collapse="; ;")
 res
}

#--functions to process ORF annotations derived from SPADes contig sequences (mostly due to specific header annotations)
strip.after.first.chr<-function(S,chr)
{
 #--'S' is a character vector
 res<-sapply(strsplit(S,chr,fixed=T),FUN=function(x){x[[1]][1]})
 return(res)
}

convert.tax.anno.strings.to.list.spades<-function(orfTaxAnno)
{
 res<-list()
 O<-length(orfTaxAnno)
 for(o in (1:O))
 {
  curorf<-orfTaxAnno[o]
  curorftag<-strip.after.first.chr(curorf,";")
  curres<-orf.lcam::process.tax.to.nel(curorf)
  curout<-curres$ew
  names(curout)<-curres$nel[,"second"]
  res[[curorftag]]<-curout
 }
 return(res)
}

process.ORF.annotations.spades<-function(taxScan,contig2orfTable,contigsToUse,level=c("d","p","c","o","f","g","s"))
{
 res<-list(contig2orfList=NULL,taxaToExtract=NULL,taxScanSelected=NULL)
 taxScan.orfids<-strip.after.first.chr(taxScan,";")
 contig2orfTableCut<-contig2orfTable[contig2orfTable$contig%in%contigsToUse,]
 res$contig2orfList<-tapply(as.character(contig2orfTableCut$orf),INDEX=contig2orfTableCut$contig,FUN=function(x){x})
 mind<-which((taxScan.orfids %in% contig2orfTableCut$orf)==T)
 taxScanToUse<-taxScan[mind]
 names(taxScanToUse)<-taxScan.orfids[mind]
 taxScanToUse.annoList<-convert.tax.anno.strings.to.list.spades(taxScanToUse)
 taxScanToUse.annoList.cut100<-lapply(taxScanToUse.annoList,FUN=function(x){x[x == 100]})
 taxScanToUse.annoList.cut100.level<-lapply(taxScanToUse.annoList.cut100,FUN=orf.lcam::extract.at.level,l=paste(level,"__",sep=""))
 res$taxaToExtract<-orf.lcam::process.annoListResults(taxScanToUse.annoList.cut100.level)
 res$taxScanSelected<-taxScanToUse
 return(res)
}

#--make a new function which exports at the TOI step...
extract.contig.level.results<-function(orfAnnoList)
{
 #--'orfAnnoList' is a list output from 'process.ORF.annotations'
 res<-list()
 for(curtaxon in names(orfAnnoList$taxaToExtract))
 {
  print(curtaxon)
  curres1<-extract.orf2tax.graph.for.taxa.of.interest(orfAnnoList$taxScanSelected,curtaxon)
  curres2<-generate.toi.summary.results(orfAnnoList$contig2orfList,curres1)
  res[[curtaxon]]<-curres2
 }
 return(res)
}

calculate.j.statistics<-function(contigLevelRes,contigs)
{
 #--'contigLevelRes' is an output from 'extract.contig.level.results'
 #--contigs are the set of background contigs
 #--the output is a matrix with length(contigs) rows and the number of columns determined by the number of observed annotations
 #--elements are the mean annotation statistics for each contig-taxon combination
 ccontigs<-intersect(unique(unlist(sapply(contigLevelRes,rownames))),contigs)
 ccontigLevelRes<-lapply(contigLevelRes,FUN=function(X,s){X[intersect(s,rownames(X)),]},s=ccontigs)
 ccontigLevelResCut<-ccontigLevelRes[which(sapply(ccontigLevelRes,nrow)>0)]
 res<-matrix(0,length(contigs),length(ccontigLevelResCut))
 rownames(res)<-contigs
 colnames(res)<-names(ccontigLevelResCut)
 for(curres in names(ccontigLevelResCut))
 {
  res[rownames(ccontigLevelResCut[[curres]]),curres]<-ccontigLevelResCut[[curres]]$mean
 }
 res
}

define.neighbourhoods<-function(bM,k,scale=c(T,F))
{
 #--'bM' is a matrix with rows indexing contigs and 2 columns that index binning variables (e.g. two coverage vectors or one coverage and one GC, etc)
 #--'k' is the (maximum) number of nearest neighbours you want to define
 if(scale==T)
 {
  mat<-scale(bM,T,T)
  mat.nn2<-RANN::nn2(mat,k=k)
 }
 else
 if(scale==F)
 {
  mat.nn2<-RANN::nn2(bM,k=k)
 }
 
 #--convert bMColScale.nn2[[1]] to a membership list
 res<-list()
 for(currow in (1:nrow(mat.nn2[[1]])))
 {
  curcontig<-rownames(bM)[currow]
  res[[curcontig]]<-rownames(bM)[mat.nn2[[1]][currow,]]
 }
 return(res)
}

calculate.k.statistics<-function(JStatMat,contigSetList)
{
 #--calculate K-statistics for all columns of 'JStatMat' for contig sets in 'contigSetList'
 #--returns a matrix with contig sets indexed in rows and taxa indexed in columns
 #--filter neighbourhoods for contigs actually in 'JStatMat'
 contigSetList<-lapply(contigSetList,intersect,y=rownames(JStatMat))
 contigSetListFiltered<-contigSetList[sapply(contigSetList,length)>1]

 #--calculate mean annotation statistics for all neighbourhoods
 res=NULL
 for(curcset in names(contigSetListFiltered))
 {
  print(curcset)
  res<-rbind(res,apply(JStatMat[contigSetListFiltered[[curcset]],],2,mean))
 }
 rownames(res)<-names(contigSetListFiltered)
 res
}

#--a function to read in a contig set from MetaBat or another binner that returns (SPAdes) contigs per bin in FASTA form
read.bin.fasta<-function(filepath,extension=".fa")
{
 #--assume that in given directory specified by 'filepath', there will be a set of '.<extension> files (assumed to be ".fa")
 #--read in all these and store as a list ('fastaList')
 require(Biostrings)
 files<-list.files(patt=extension,path=filepath,full.names=F)
 
 #--read in and store as list elements
 fastaList<-list()
 for(curfile in files)
 {
  curfasta<-readDNAStringSet(paste(filepath,curfile,sep="/"))
  fastaList[[curfile]]<-sapply(strsplit(names(curfasta),"_"),FUN=function(x){paste(x[1],x[2],sep="_")})
 }
 
 #--remove the .<extension> tag from names of fastaList
 names(fastaList)<-sapply(strsplit(names(fastaList),extension,fixed=T),FUN=function(x){x[1]})
 
 return(fastaList)
}

#--this are so simple I think they be specificed in the vignette!
#--couple of functions to extract data from a fastaList
#extract.contig.names.from.fastaList<-function(fastaList){lapply(fastaList,names)}
#extract.contig.lengths.from.fastaList<-function(fastaList){lapply(fastaList,nchar)}
#extract.total.contig.length.from.fastaList<-function(fastaList){sapply(fastaList,FUN=function(x){sum(nchar(x))})}

#--not sure if we need this?
#--calculate proportion of neighbourhood that is in a set of bins.
calculate.overlaps.between.two.bin.sets<-function(L1,L2)
{
 #--'L1' and 'L2' are lists whose elements contain contigs from a given bin
 #--compute Jaccard metric for each combination of bins in each set and outut as a matrix
 confusionMat<-matrix(NA,length(L1),length(L2))
 for(i in (1:(nrow(confusionMat))))
 {
  print(i)
  for(j in (1:ncol(confusionMat)))
  {
   confusionMat[i,j]<-length(intersect(L1[[i]],L2[[j]]))
  }
 }
 rownames(confusionMat)<-names(L1)
 colnames(confusionMat)<-names(L2)
 confusionMat
}

#--neighbourhood extraction from a seed contig
grow.neighbourhood.from.seed<-function(bM,target,nhs=seq(10,500,10))
{
 #--'bM' is a binning space matrix, with contigs index in rows and variables in columns (can have >2 columns)
 #--'target' is a row entity that is the neighbourhood centre
 #--'nhs' is a vector with the neighbourhood sizes you want to capture using RANN::nn2
 #--returns a list with the contig memberships of each neighbourhood
 res<-list()
 
 #--precalculate a scaled version of bM
 bMS<-scale(bM,T,T)
 
 for(cursize in nhs)
 {
  print(cursize)
  res[[as.character(cursize)]]<-define.neighbourhoods(bMS,cursize,F)[[target]]
 }
 res
}

#--once you have "grown" a neighbourhood series, export the contigs for analysis in CheckM using this function
#--make a set of FASTA files...
make.FASTA.file.set<-function(contigMembershipList,contigSeqSet,dirName)
{
 #--'contigMembershipList' is a list whose elements contain contig names (i this case, an output from 'grow.neighbourhood.from.seed')
 #--'contigSeqSet' is a DNStringSet object containing the complete set of contigs in the assembly
 #--'dirName' is a directory path, that will be made when the function runs: suggest storing neighbourhood sets in different directories!
 system(paste("mkdir",dirName,sep=" "))
 for(curset in names(contigMembershipList))
 {
  curfp<-paste(dirName,"/",curset,".fna",sep="")
  curfasta<-contigSeqSet[contigMembershipList[[curset]]]
  writeXStringSet(x=curfasta,filepath=curfp,format="fasta",append=F)
  print(curfp)
 }
}

